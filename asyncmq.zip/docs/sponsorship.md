# Help AsyncMQ

Do you like **AsyncMQ** and would like to help AsyncMQ, other user and the author?

## 🐦 Follow AsyncMQ on Twitter


## ⭐ Star **AsyncMQ** on GitHub

Giving a star to AsyncMQ is very simple and helps promoting the work across the developers around the world.

The button is located at the top right.

[https://github.com/dymmond/asyncmq](https://github.com/dymmond/asyncmq).

This will help spreading the word about the tool and how helpful has been.

## 👀 Follow the GitHub repo

Following the GitHub repo will allow you to "watch" for any new release of AsyncMQ and be always up to date.

You can click on "***watch***" and select "***custom***" -> "***Releases***"or any other you may find particular
interesting to you.

## 💬 Join the official AsyncMQ discord channel

## 🔥 Sponsor the author

The author built this framework with all of his heart and dedication and will continue to do it so but that also
requires time and resources and when they are limited, the process still gets there but takes a bit longer.

You can financially help and support the author though [GitHub sponsors](https://github.com/sponsors/tarsil)

He can afterwards go for a coffee☕, on him, to say thanks🙏.
